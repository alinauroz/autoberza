import ForgotPassword from '@/components/ForgotPassword';

export default ForgotPassword;
