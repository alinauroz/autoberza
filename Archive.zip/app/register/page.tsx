import SignUp from '@/components/SignUpPage';

export default SignUp;
