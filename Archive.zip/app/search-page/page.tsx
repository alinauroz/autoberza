import SearchPage from '@/components/SearchPage';

export default SearchPage;
