import OtpVerification from '@/components/OtpVerification';
export default OtpVerification;
