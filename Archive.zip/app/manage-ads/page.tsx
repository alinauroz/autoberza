import MyAds from '@/components/MyAds';

export default MyAds;
