import AdminPanel from '@/components/AdminPanel';

export default AdminPanel;
