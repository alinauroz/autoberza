import Verification from '@/components/Verification';
import React from 'react';

function Page() {
  return <Verification />;
}

export default Page;
