import PostAd from '@/components/PostAd';

export default PostAd;
