import EmailVerification from '@/components/EmalVarification';

export default EmailVerification;
