export const RESET_PASSWORD_RESPONSE = 'Email sent';
export const VERIFICATION_EMAIL_SENT =
  'Verification email would be sent to the user if the user existed';
