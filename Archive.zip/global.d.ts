declare module 'graphql-client';
